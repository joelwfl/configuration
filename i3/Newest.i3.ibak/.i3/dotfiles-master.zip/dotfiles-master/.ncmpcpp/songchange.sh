#!/bin/bash

notify-send "`mpc current`"
